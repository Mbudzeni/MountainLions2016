<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2014 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

return array(
    'router' => array(
        'routes' => array(
            'home' => array(
                'type' => 'Zend\Mvc\Router\Http\Literal',
                'options' => array(
                    'route'    => '/',
                    'defaults' => array(
                        'controller' => 'EG1\Controller\Index',
                        'action'     => 'index',
                    ),
                ),
            ),
            'contact' => array(
                'type' => 'Literal',
                'options' => array(
                    'route' => '/contact',
                    'defaults' => array(
                        'controller' => 'EG1\Controller\Index',
                        'action' => 'contact',
                    ),
                ),
            ),
            'about' => array(
                'type' => 'Literal',
                'options' => array(
                    'route' => '/about',
                    'defaults' => array(
                        'controller' => 'EG1\Controller\Index',
                        'action' => 'about',
                    ),
                ),
            ),
            'past' => array(
                'type' => 'Literal',
                'options' => array(
                    'route' => '/past',
                    'defaults' => array(
                        'controller' => 'EG1\Controller\Index',
                        'action' => 'past',
                    ),
                ),
            ),
            'upcoming' => array(
                'type' => 'Literal',
                'options' => array(
                    'route' => '/upcoming',
                    'defaults' => array(
                        'controller' => 'EG1\Controller\Index',
                        'action' => 'upcoming',
                    ),
                ),
            ),
            'current' => array(
                'type' => 'Literal',
                'options' => array(
                    'route' => '/current',
                    'defaults' => array(
                        'controller' => 'EG1\Controller\Index',
                        'action' => 'current',
                    ),
                ),
            ),
            'exhibitions' => array(
                'type' => 'Literal',
                'options' => array(
                    'route' => '/exhibitions',
                    'defaults' => array(
                        'controller' => 'EG1\Controller\Index',
                        'action' => 'exhibitions',
                    ),
                ),
            ),
            'artists' => array(
                'type' => 'Literal',
                'options' => array(
                    'route' => '/artists',
                    'defaults' => array(
                        'controller' => 'EG1\Controller\Index',
                        'action' => 'artists',
                    ),
                ),
            ),
            'registration' => array(
                'type' => 'Literal',
                'options' => array(
                    'route' => '/registration',
                    'defaults' => array(
                        'controller' => 'EG1\Controller\Index',
                        'action' => 'registration',
                    ),
                ),
            ),
            'past2013' => array(
                'type' => 'Literal',
                'options' => array(
                    'route' => '/past2013',
                    'defaults' => array(
                        'controller' => 'EG1\Controller\Index',
                        'action' => 'past2013',
                    ),
                ),
            ),
            'past2014' => array(
                'type' => 'Literal',
                'options' => array(
                    'route' => '/past2014',
                    'defaults' => array(
                        'controller' => 'EG1\Controller\Index',
                        'action' => 'past2014',
                    ),
                ),
            ),
            'past2015' => array(
                'type' => 'Literal',
                'options' => array(
                    'route' => '/past2015',
                    'defaults' => array(
                        'controller' => 'EG1\Controller\Index',
                        'action' => 'past2015',
                    ),
                ),
            ),
            
            // The following is a route to simplify getting started creating
            // new controllers and actions without needing to create a new
            // module. Simply drop new controllers in, and you can access them
            // using the path /application/:controller/:action
            'EG1' => array(
                'type'    => 'Literal',
                'options' => array(
                    'route'    => '/EG1',
                    'defaults' => array(
                        '__NAMESPACE__' => 'EG1\Controller',
                        'controller'    => 'Index',
                        'action'        => 'index',
                    ),
                ),
                
                    
                
                
                'may_terminate' => true,
                'child_routes' => array(
                    'default' => array(
                        'type'    => 'Segment',
                        'options' => array(
                            'route'    => '/[:controller[/:action]]',
                            'constraints' => array(
                                'controller' => '[a-zA-Z][a-zA-Z0-9_-]*',
                                'action'     => '[a-zA-Z][a-zA-Z0-9_-]*',
                            ),
                            'defaults' => array(
                            ),
                        ),
                    ),
                ),
            ),
        ),
    ),
    
    'navigation' => array(
        'default' => array(
            array(
                    'label' => 'Login',
                    'route' => 'login',
                    'action' => 'login',
                    ),
            array(
                    'label' => 'Register',
                    'route' => 'registration',
                    'action' => 'registration',
                    ),
                ),
            ),
    
    'service_manager' => array(
        'abstract_factories' => array(
            'Zend\Cache\Service\StorageCacheAbstractServiceFactory',
            'Zend\Log\LoggerAbstractServiceFactory',
        ),
        'aliases' => array(
            'translator' => 'MvcTranslator',
        ),
    ),
    'translator' => array(
        'locale' => 'en_US',
        'translation_file_patterns' => array(
            array(
                'type'     => 'gettext',
                'base_dir' => __DIR__ . '/../language',
                'pattern'  => '%s.mo',
            ),
        ),
    ),
    'controllers' => array(
        'invokables' => array(
            'EG1\Controller\Index' => 'EG1\Controller\IndexController'
        ),
    ),
    'view_manager' => array(
        'display_not_found_reason' => true,
        'display_exceptions'       => true,
        'doctype'                  => 'HTML5',
        'not_found_template'       => 'error/404',
        'exception_template'       => 'error/index',
        'template_map' => array(
            'layout/layout'           => __DIR__ . '/../view/layout/layout.phtml',
            'application/index/index' => __DIR__ . '/../view/application/index/index.phtml',
            'error/404'               => __DIR__ . '/../view/error/404.phtml',
            'error/index'             => __DIR__ . '/../view/error/index.phtml',
        ),
        'template_path_stack' => array(
            __DIR__ . '/../view',
        ),
    ),
    // Placeholder for console routes
    'console' => array(
        'router' => array(
            'routes' => array(
            ),
        ),
    ),
);
