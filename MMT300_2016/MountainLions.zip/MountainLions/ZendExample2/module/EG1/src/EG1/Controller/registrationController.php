<?php
namespace Application\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;

use Application\Model\Auth;
use Application\Form\RegistrationFilter;
use Application\Form\RegistrationForm;

class RegistrationController extends AbstractActionController
{
	protected $customersTable;
        
        public function getCustomersTable()
     {
         if (!$this->customersTable) {
             $sm = $this->getServiceLocator();
             $this->customersTable = $sm->get('Application\Model\customersTable');
         }
         return $this->customersTable;
     }
 
    public function registrationAction()
	{
		// A test instantiation to make sure it works. Not used in the application. You can remove the next line
		// $myValidator = new ConfirmPassword();
		$form = new RegistrationForm();
		$form->get('submit')->setValue('Register');
		
		$request = $this->getRequest();
                if ($request->isPost()) {
			$form->setInputFilter(new RegistrationFilter($this->getServiceLocator()));
			$form->setData($request->getPost());
			 if ($form->isValid()) {			 
				$data = $form->getData();
                             
				$auth = new Auth();
				$auth->exchangeArray($data);
                                $this->getCustomersTable()->saveCustomers($auth);
/*				
				// this is replaced by 
				// 1) Manualy composing (wiring) the objects
				$dbAdapter = $this->getServiceLocator()->get('Zend\Db\Adapter\Adapter');
				$resultSetPrototype = new \Zend\Db\ResultSet\ResultSet();
				$resultSetPrototype->setArrayObjectPrototype(new \Auth\Model\Auth());
				$tableGateway = new \Zend\Db\TableGateway\TableGateway('users', $dbAdapter, null, $resultSetPrototype);
				$usersTable = new \Auth\Model\UsersTable($tableGateway);
				// $usersTable->saveUser($auth);
				// $user7 = $usersTable->getUser(7);
				
				$rowset = $tableGateway->select(array('usr_id' => 7));
				$user7 = $rowset->current();
				
				echo '<pre>';
				var_dump($user7);
				echo '</pre>';
*/
				
				// OR
				// 2) Using the service Locator
				
				
			//	 return $this->redirect()->toRoute('application/default', 
                       //array('controller'=>'index', 'action'=>'index'));					
			}			 
		}
		return new ViewModel(array('form' => $form));
	}
}