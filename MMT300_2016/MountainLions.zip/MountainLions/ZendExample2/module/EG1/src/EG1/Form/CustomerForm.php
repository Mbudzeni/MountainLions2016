<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of CustomerForm
 *
 * @author Pepukayi Chitondo
 */

namespace EG1\Form;

use Zend\Form\Form;
use Zend\InputFilter\InputFilter;

class CustomerForm extends Form 
{
    public function __construct()
    {
       // Define form name
       parent::__construct('customer-form');
       // Set POST method for this form
       $this->setAttribute('method', 'post');
       
       // (Optionally) set action for this form
       //$this->setAttribute('action', '/contactus');
       
       $this->addElements();
       $this->addInputFilter();
    }
    
    protected function addElements()
    {
        // Add "name" field
        $this->add(array(            
            'type'  => 'text',
            'name' => 'Name',
            'attributes' => array(
                'id' => 'Name',
              
            ),
            'options' => array(
                'label' => 'Your Name',
            ),
        ));
        
        // Add "email" field
        $this->add(array(            
            'type'  => 'text',
            'name' => 'email',
            'attributes' => array(
                'id' => 'email',
              
            ),
            'options' => array(
                'label' => 'Your Email',
            ),
        ));
        
        // Add "password" field
        $this->add(array(            
            'type'  => 'text',
            'name' => 'password',
            'attributes' => array(
                'id' => 'password',
              
            ),
            'options' => array(
                'label' => 'Your Password',
            ),
        ));
        
        // Add "confirm password" field
        $this->add(array(            
            'type'  => 'text',
            'name' => 'confirm-password',
            'attributes' => array(
                'id' => 'confirm-password',
              
            ),
            'options' => array(
                'label' => 'Confirm Password',
            ),
        ));
        
         $this->add(array(
            'type'  => 'submit',
            'name' => 'submit',
            'attributes' => array(                
                'value' => 'Submit',
                'id' => 'submitbutton',
            ),
        ));
    }
    
    private function addInputFilter()
    {
        $inputFilter = new InputFilter();        
        $this->setInputFilter($inputFilter);
        
        $inputFilter->add(array(
                'name'     => 'email',
                'required' => true,
                'filters'  => array(
                    array('name' => 'StringTrim'),                    
                ),                
                'validators' => array(
                    array(
                        'name' => 'EmailAddress',
                        'options' => array(
                            'allow' => \Zend\Validator\Hostname::ALLOW_DNS,
                            'useMxCheck'    => false,                            
                        ),
                    ),
                ),
            )
        );
        
        $inputFilter->add(array(
                'name'     => 'Name',
                'required' => true,
                'filters'  => array(
                    array('name' => 'StringTrim'),
                    array('name' => 'StripTags'),
                ),                
                'validators' => array(
                    array(
                        'name'    => 'StringLength',
                        'options' => array(
                            'min' => 1,
                            'max' => 30
                        ),
                    ),
                ),
            )
        );
        
        $inputFilter->add(array(
			'name'     => 'password',
			'required' => true,
			'filters'  => array(
				array('name' => 'StripTags'),
				array('name' => 'StringTrim'),
			),
			'validators' => array(
				array(
					'name'    => 'StringLength',
					'options' => array(
						'encoding' => 'UTF-8',
						'min'      => 6,
						'max'      => 12,
					),
				),
			),
		));
        
        $inputFilter->add(array(
			'name'     => 'confirm-password',
			'required' => true,
			'filters'  => array(
				array('name' => 'StripTags'),
				array('name' => 'StringTrim'),
			),
			'validators' => array(
				array(
					'name'    => 'StringLength',
					'options' => array(
						'encoding' => 'UTF-8',
						'min'      => 6,
						'max'      => 12,
					),
				),
                                array(
                                    'name'    => 'Identical',
                                    'options' => array(
                                        'token' => 'password',
                                    ),
                                ),
			),
		));
    }
}
