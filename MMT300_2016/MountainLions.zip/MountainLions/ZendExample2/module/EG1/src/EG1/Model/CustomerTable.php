<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of CustomerTable
 *
 * @author Pepukayi
 */
namespace EG1\Model;

use Zend\Db\TableGateway\TableGateway;   

class CustomerTable 
{
    protected $tableGateway;

     public function __construct(TableGateway $tableGateway)
     {
         $this->tableGateway = $tableGateway;
     }

     public function fetchAll()      //retrieve all the records in the customer table
     {
         $resultSet = $this->tableGateway->select();    //SELECT * FROM customer;  
         return $resultSet;
     }

     public function getCustomer($email)     // retrieves one record of customer depending on their email address 
     {
         $email  = $email;
         $rowset = $this->tableGateway->select(array('usr_email' => $email)); 
                                        //SELECT * FROM customer WHERE email = $email;
         $row = $rowset->current();
         if (!$row) {
             throw new \Exception("Could not find row $email");
         }
         return $row;
     }

     public function saveCustomer(Customer $cust)    // will save record to database 
     {
         $data = array(
             'usr_name'  => $cust->usr_name,
             'usr_password'  => $cust->usr_password,
             'usr_email' => $cust->usr_email,
         );

         $email = $cust->usr_email;
         if ($email == 0) {
             $this->tableGateway->insert($data);    //INSERT INTO customer VALUES($data);
         } else {
             if ($this->getCustomer($email)) {
                 $this->tableGateway->update($data, array('usr_email' => $email)); //UPDATE ...
             } else {
                 throw new \Exception('Email does not exist');
             }
         }
     }

     public function deleteCustomer($email)   // delete a record 
     {
         $this->tableGateway->delete(array('usr_email' => $email));   //DELETE...
     }
}
