<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2014 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace EG1\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use EG1\Form\RegistrationForm;
use EG1\Model\Registration;

class IndexController extends AbstractActionController
{
    protected $customerTable;
    public function getCustomerTable()
    {
         if (!$this->customerTable) {
             $sm = $this->getServiceLocator();
             $this->customerTable = $sm->get('EG1\Model\CustomerTable');
         }
         return $this->customerTable;
     }
     
    public function indexAction()
    {
        return new ViewModel();
    }
   
   
     public function Action()
    {
       
       $name = "Pepukayi";
       return new ViewModel(
               array("Name"  => $name,)
               );
    }
    
    public function aboutAction()
    {
        //$this->layout()->setTemplate('layout/layout2');
        return new ViewModel();
    }
    
    public function eventsAction()
    {
        $form = new CustomerForm();
        
        if($this->getRequest()->isPost()) {
            
            // Fill in the form with POST data
            $data = $this->params()->fromPost();            
            
            $form->setData($data);
            echo $data['email'];
            
            // Validate form
            if($form->isValid()) {
                
                // Get filtered and validated data
                $data = $form->getData();
                echo $data['email'];
                $customer = new Customer();
                $customer->exchangeArray($data);
                echo $customer->usr_email;
                /*$email = $data['email'];
                $name = $data['name'];
                $password = $data['password'];*/
                
                //$customer->exchangeArray($form->getData());
                $this->getCustomerTable()->saveCustomer($customer);
                
                // Redirect to "Thank You" page
                return $this->redirect()->toRoute('EG1/default', 
                        array('controller'=>'index', 'action'=>'artists'));
            }               
        } 
        
        return new ViewModel(
                array(
            'form' => $form
        ));
    }
    
     public function artistsAction()
    {
        return new ViewModel();
    }
  public function contactAction()
    {
        return new ViewModel();
}
public function pastAction()
    {
        return new ViewModel();
}
public function upcomingAction()
    {
        return new ViewModel();
}
public function currentAction()
    {
        return new ViewModel();
}
public function registrationAction()
    {
        return new ViewModel();
}
public function exhibitionsAction()
    {
        return new ViewModel();
}
public function past2013Action()
    {
        return new ViewModel();
}
public function past2014Action()
    {
        return new ViewModel();
}
public function past2015Action()
    {
        return new ViewModel();
}
}