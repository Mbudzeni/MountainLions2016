<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
namespace Application\Form;

use Zend\Form\Form;

class RegistrationForm extends Form
{
    public function __construct($name = null)
    {
        parent::__construct('registration');
        $this->setAttribute('method','post');
        
        $this->add(array(
            'name' => 'Cust_FirstName',
            'attribute' => array(
              'type' => 'text',  
            ),
            'options' => array(
              'label' => 'First Name ',  
            ),
        ));
        $this->add(array(
            'name' => 'Cust_LastName',
            'attribute' => array(
              'type' => 'text',  
            ),
            'options' => array(
              'label' => 'Last Name ',  
            ),
        ));
        
        $this->add(array(
            'name' => 'Cust_Email',
            'attribute' => array(
              'type' => 'email',  
            ),
            'options' => array(
              'label' => 'E-mail',  
            ),
        ));
        $this->add(array(
            'name' => 'Cust_PhoneNumber',
            'attribute' => array(
              'type' => 'Number',  
            ),
            'options' => array(
              'label' => 'Phone Number',  
            ),
        ));
        
        $this->add(array(
            'name' => 'username',
            'attribute' => array(
              'type' => 'Text',  
            ),
            'options' => array(
              'label' => 'Username ',  
            ),
        ));
        
        $this->add(array(
            'name' => 'password',
            'attribute' => array(
              'type' => 'password',  
            ),
            'options' => array(
              'label' => 'Password',  
            ),
        ));
        
        $this->add(array(
            'name' => 'password_confirm',
            'attribute' => array(
              'type' => 'password',  
            ),
            'options' => array(
              'label' => 'Confirm Password',  
            ),
        ));
        
        $this->add(array(
            'name' => 'submit',
            'attribute' => array(
              'type' => 'submit', 
                'Value' => 'go',
                'id' => 'submitbutton',
            ),
        ));
    }
}
